// UNO Multiplayer server – Node.js + WebSocket (ws)
// Varianta 2: 1–4 jucatori, cu inregistrare/logare in baza de date si declarare UNO.

const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');
const Database = require('better-sqlite3');

const PORT = 3000;

// ----------------- BAZA DE DATE -----------------
const db = new Database('uno_database.db');

// Creeaza tabela daca nu exista
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  
  CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    client_id INTEGER NOT NULL,
    logged_in_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (username) REFERENCES users(username)
  );
`);

// Functii helper pentru baza de date
function getUserByUsername(username) {
  const stmt = db.prepare('SELECT * FROM users WHERE username = ?');
  return stmt.get(username);
}

function createUser(username, password) {
  try {
    const stmt = db.prepare('INSERT INTO users (username, password) VALUES (?, ?)');
    stmt.run(username, password);
    return true;
  } catch (error) {
    return false; // Username deja exista sau alta eroare
  }
}

function isUserLoggedIn(username) {
  // Verifica daca exista un client activ (conectat) cu acest username
  const activeClient = clients.find(c => c.loggedIn && c.username === username);
  if (activeClient) {
    return true; // Utilizatorul este logat si clientul este conectat
  }
  
  // Daca nu exista client activ, sterge sesiunile orfane din baza de date
  deleteAllSessionsForUser(username);
  return false; // Nu este logat sau sesiunea era expirata
}

function createSession(username, clientId) {
  const stmt = db.prepare('INSERT INTO sessions (username, client_id) VALUES (?, ?)');
  stmt.run(username, clientId);
}

function deleteSession(username, clientId) {
  const stmt = db.prepare('DELETE FROM sessions WHERE username = ? AND client_id = ?');
  stmt.run(username, clientId);
}

function deleteAllSessionsForUser(username) {
  const stmt = db.prepare('DELETE FROM sessions WHERE username = ?');
  stmt.run(username);
}

// ----------------- HTTP SERVER (serveste index.html + resursele statice) -----------------

const server = http.createServer((req, res) => {
  let filePath = req.url === '/' ? '/index.html' : req.url;
  // Serve admin.html for /admin route
  if (req.url === '/admin' || req.url === '/admin.html') {
    filePath = '/admin.html';
  }
  const fullPath = path.join(__dirname, 'public', filePath);

  fs.readFile(fullPath, (err, data) => {
    if (err) {
      res.writeHead(404);
      return res.end('Not found');
    }
    let ext = path.extname(fullPath);
    let contentType = 'text/html';
    if (ext === '.css') contentType = 'text/css';
    else if (ext === '.js') contentType = 'application/javascript';

    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  });
});

// ----------------- WEBSOCKET SERVER -----------------

const wss = new WebSocket.Server({ server });

let nextPlayerId = 1;
let clients = []; // { ws, id, name, loggedIn, username }
let game = null;

// Structura jocului
function createNewGame() {
  return {
    started: false,
    deck: buildDeck(),
    discard: [],
    hands: new Map(),   // playerId -> [cards]
    currentColor: null,
    currentPlayerId: null,
    direction: 1,
    pendingDraw: 0  // numarul de carti de tras pentru urmatorul jucator
  };
}

// Carti: culori + valori simple + cateva WILD
const COLORS = ['red', 'yellow', 'green', 'blue'];
const VALUES = ['0','1','2','3','4','5','6','7','8','9'];

function buildDeck() {
  const d = [];
  for (const c of COLORS) {
    for (const v of VALUES) {
      d.push({ color: c, value: v });
      if (v !== '0') d.push({ color: c, value: v });
    }
    // Adauga carti +2 pentru fiecare culoare (2 carti per culoare)
    d.push({ color: c, value: '+2' });
    d.push({ color: c, value: '+2' });
    // Adauga carti REVERSE pentru fiecare culoare (2 carti per culoare)
    d.push({ color: c, value: 'REVERSE' });
    d.push({ color: c, value: 'REVERSE' });
    // Adauga carti SKIP pentru fiecare culoare (2 carti per culoare)
    d.push({ color: c, value: 'SKIP' });
    d.push({ color: c, value: 'SKIP' });
  }
  // Adauga carti WILD si WILD +4
  for (let i = 0; i < 4; i++) {
    d.push({ color: 'wild', value: 'WILD' });
  }
  for (let i = 0; i < 4; i++) {
    d.push({ color: 'wild', value: '+4' });
  }
  shuffle(d);
  return d;
}

function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
}

function reshuffleIfNeeded() {
  if (!game) return;
  if (game.deck.length === 0 && game.discard.length > 1) {
    const top = game.discard.pop();
    game.deck = game.discard.slice();
    shuffle(game.deck);
    game.discard = [top];
  }
}

// Distribuie carti initial
function dealInitialCards() {
  const activePlayers = clients.filter(c => c.loggedIn);
  for (const c of activePlayers) {
    const hand = [];
    for (let i = 0; i < 7; i++) {
      hand.push(game.deck.pop());
    }
    game.hands.set(c.id, hand);
  }

  // prima carte pe masa (nu poate fi wild sau +2 sau +4 sau REVERSE sau SKIP)
  let first;
  do {
    first = game.deck.pop();
  } while ((first.color === 'wild' || first.value === '+2' || first.value === '+4' || first.value === 'REVERSE' || first.value === 'SKIP') && game.deck.length > 0);
  game.discard.push(first);
  game.currentColor = first.color;
  game.pendingDraw = 0;
}

// Verifica daca o carte poate fi jucata
function canPlay(card, top, currentColor) {
  if (!card || !top) return false;
  // Carte WILD sau +4 poate fi jucata oricand
  if (card.color === 'wild') return true;
  // Carte +2 poate fi jucata daca culoarea se potriveste sau daca exista un +2 pe masa
  if (card.value === '+2') {
    if (card.color === currentColor) return true;
    if (top.value === '+2') return true; // Poate pune +2 peste +2
    return false;
  }
  // Carte REVERSE sau SKIP: culoare sau valoare se potriveste
  if (card.value === 'REVERSE' || card.value === 'SKIP') {
    if (card.color === currentColor) return true;
    if (card.value === top.value) return true; // Poate pune REVERSE peste REVERSE, SKIP peste SKIP
    return false;
  }
  // Carte normala: culoare sau valoare se potriveste
  if (card.color === currentColor) return true;
  if (card.value === top.value) return true;
  return false;
}

function getNextPlayerId() {
  if (!game) return null;
  const active = clients.filter(c => c.loggedIn);
  if (active.length === 0) return null;
  const ids = active.map(c => c.id);
  let idx = ids.indexOf(game.currentPlayerId);
  if (idx === -1) idx = 0;
  idx = (idx + game.direction + ids.length) % ids.length;
  return ids[idx];
}

// Trimite starea jocului tuturor jucatorilor
function broadcastState() {
  if (!game) return;
  const top = game.discard[game.discard.length - 1] || null;
  const active = clients.filter(c => c.loggedIn);

  for (const c of clients) {
    const msg = {
      type: 'state',
      youId: c.id,
      loggedIn: !!c.loggedIn,
      username: c.username || null,
      players: active.map(p => ({
        id: p.id,
        name: p.username || p.name,
        handCount: (game.hands.get(p.id) || []).length
      })),
      hand: c.loggedIn ? (game.hands.get(c.id) || []) : [],
      topCard: top,
      currentColor: game.currentColor,
      currentPlayerId: game.currentPlayerId,
      started: game.started,
      pendingDraw: game.pendingDraw || 0,
      direction: game.direction || 1
    };
    sendJson(c.ws, msg);
  }
}

function sendJson(ws, obj) {
  try {
    ws.send(JSON.stringify(obj));
  } catch (e) {
    // ignoram erorile de trimitere
  }
}

function broadcastText(text) {
  for (const c of clients) {
    sendJson(c.ws, { type: 'info', message: text });
  }
}

// Cand se conecteaza un client
wss.on('connection', (ws) => {
  const playerId = nextPlayerId++;
  const name = 'Client ' + playerId;
  const client = { ws, id: playerId, name, loggedIn: false, username: null };
  clients.push(client);

  if (!game) game = createNewGame();

  console.log(`Client conectat: ${name}`);

  sendJson(ws, { type: 'welcome', id: playerId, name });
  setTimeout(() => {
    sendJson(ws, { type: 'info', message: 'Te rog sa te inregistrezi sau sa te loghezi.' });
  }, 200);

  ws.on('message', (data) => {
    let msg;
    try {
      msg = JSON.parse(data.toString());
    } catch {
      return;
    }
    handleMessage(client, msg);
  });

  ws.on('close', () => {
    console.log(`Client deconectat: ${client.username || name}`);
    
    // Sterge sesiunea din baza de date daca utilizatorul era logat
    if (client.loggedIn && client.username) {
      deleteSession(client.username, client.id);
      // Sterge toate sesiunile pentru acest username (in caz ca exista sesiuni orfane)
      deleteAllSessionsForUser(client.username);
    }
    
    clients = clients.filter(c => c.id !== playerId);
    if (game) {
      game.hands.delete(playerId);
      const active = clients.filter(c => c.loggedIn);
      if (active.length < 2 && game.started) {
        broadcastText('Prea putini jucatori logati. Jocul se reseteaza.');
        game = createNewGame();
      } else if (game.currentPlayerId === playerId) {
        game.currentPlayerId = getNextPlayerId();
      }
    }
    broadcastState();
  });

  broadcastState();
});

// Logica de tratare a mesajelor de la clienti
function handleMessage(client, msg) {
  if (!game) game = createNewGame();

  // ---------------- INREGISTRARE ----------------
  if (msg.type === 'register') {
    const { username, password } = msg;
    if (!username || !password) {
      sendJson(client.ws, { type: 'error', message: 'Username si parola obligatorii.' });
      return;
    }
    
    // Verifica daca username-ul exista deja in baza de date
    const existingUser = getUserByUsername(username);
    if (existingUser) {
      sendJson(client.ws, { type: 'error', message: 'Username deja folosit.' });
      return;
    }
    
    // Creeaza utilizatorul in baza de date
    const success = createUser(username, password);
    if (!success) {
      sendJson(client.ws, { type: 'error', message: 'Eroare la inregistrare. Username poate fi deja folosit.' });
      return;
    }
    
    sendJson(client.ws, { type: 'info', message: 'Înregistrare reusita. Acum te poti loga.' });
    return;
  }

  // ---------------- LOGARE ----------------
  if (msg.type === 'login') {
    const { username, password } = msg;
    
    // Verifica daca utilizatorul exista in baza de date
    const user = getUserByUsername(username);
    if (!user || user.password !== password) {
      sendJson(client.ws, { type: 'error', message: 'Date de logare invalide.' });
      return;
    }
    
    // Verifica daca utilizatorul este deja logat si are client activ conectat
    const activeClient = clients.find(c => c.loggedIn && c.username === username && c.id !== client.id);
    if (activeClient) {
      // Verifica daca conexiunea clientului activ este inca deschisa
      if (activeClient.ws.readyState === WebSocket.OPEN) {
        sendJson(client.ws, { type: 'error', message: 'Acest utilizator este deja logat. Nu poti fi logat cu acelasi nume de doua ori.' });
        return;
      } else {
        // Clientul activ nu mai este conectat, sterge sesiunea orfana
        console.log(`Stergere sesiune orfana pentru ${username}`);
        deleteAllSessionsForUser(username);
        // Marcheaza clientul vechi ca delogat
        activeClient.loggedIn = false;
        activeClient.username = null;
      }
    } else {
      // Nu exista client activ, dar sterge sesiuni orfane din DB
      deleteAllSessionsForUser(username);
    }
    
    // Logheaza utilizatorul
    client.loggedIn = true;
    client.username = username;
    client.name = username;
    createSession(username, client.id);
    
    sendJson(client.ws, { type: 'info', message: 'Logare reusita. Poti intra in joc.' });
    broadcastState();
    return;
  }

  // ---------------- ADMIN ACTIONS (nu necesita logare pentru admin) ----------------
  if (msg.type === 'admin') {
    // Pentru simplitate, permitem admin fara autentificare speciala
    // In productie, ar trebui sa verifici un token/admin password
    const { action } = msg;
    
    if (action === 'getState') {
      const active = clients.filter(c => c.loggedIn);
      const adminState = {
        type: 'adminState',
        totalClients: clients.length,
        loggedInCount: active.length,
        gameStarted: game ? game.started : false,
        currentPlayerId: game ? game.currentPlayerId : null,
        currentPlayerName: game && game.currentPlayerId ? 
          (clients.find(c => c.id === game.currentPlayerId)?.name || 'N/A') : null,
        deckCount: game ? game.deck.length : 0,
        discardCount: game ? game.discard.length : 0,
        players: clients.map(c => ({
          id: c.id,
          name: c.username || c.name,
          loggedIn: c.loggedIn,
          handCount: game && c.loggedIn ? (game.hands.get(c.id) || []).length : 0,
          isCurrent: game && game.currentPlayerId === c.id
        }))
      };
      sendJson(client.ws, adminState);
      return;
    }
    
    if (action === 'startGame') {
      if (game && game.started) {
        sendJson(client.ws, { type: 'error', message: 'Jocul a inceput deja.' });
        return;
      }
      const active = clients.filter(c => c.loggedIn);
      if (active.length < 2) {
        sendJson(client.ws, { type: 'error', message: 'Ai nevoie de minim 2 jucatori logati.' });
        return;
      }
      game.started = true;
      game.deck = buildDeck();
      game.discard = [];
      game.hands = new Map();
      dealInitialCards();
      game.currentPlayerId = active[0].id;
      broadcastText('[ADMIN] Jocul a fost pornit de administrator.');
      broadcastState();
      return;
    }
    
    if (action === 'resetGame') {
      game = createNewGame();
      broadcastText('[ADMIN] Jocul a fost resetat de administrator.');
      broadcastState();
      return;
    }
    
    if (action === 'kickAll') {
      clients.forEach(c => {
        try {
          c.ws.close();
        } catch (e) {}
      });
      clients = [];
      game = createNewGame();
      return;
    }
    
    if (action === 'clearUsers') {
      db.exec('DELETE FROM users; DELETE FROM sessions;');
      broadcastText('[ADMIN] Toate conturile au fost sterse de administrator.');
      return;
    }
    
    return;
  }

  // Orice altceva cere logare
  if (!client.loggedIn) {
    sendJson(client.ws, { type: 'error', message: 'Trebuie sa fii logat pentru a juca.' });
    return;
  }

  // ---------------- START ----------------
  if (msg.type === 'start') {
    if (game.started) {
      sendJson(client.ws, { type: 'error', message: 'Jocul a inceput deja.' });
      return;
    }

    const active = clients.filter(c => c.loggedIn);
    // MINIM 2 jucatori logati
    if (active.length < 2) {
      sendJson(client.ws, { type: 'error', message: 'Ai nevoie de minim 2 jucatori logati.' });
      return;
    }

    game.started = true;
    game.deck = buildDeck();
    game.discard = [];
    game.hands = new Map();
    game.pendingDraw = 0;

    dealInitialCards();
    game.currentPlayerId = active[0].id;

    broadcastText('Jocul a inceput!');
    broadcastState();
    return;
  }

  // ---------------- DACA JOCUL NU A INCEPUT ----------------
  if (!game.started) {
    sendJson(client.ws, { type: 'error', message: 'Jocul nu a inceput inca.' });
    return;
  }

  // ---------------- RANDUL CUI TREBUIE ----------------
  if (client.id !== game.currentPlayerId) {
    sendJson(client.ws, { type: 'error', message: 'Nu este randul tau.' });
    return;
  }

  // ---------------- PLAY (Joaca carte) ----------------
  if (msg.type === 'play') {
    const index = msg.index;
    const unoDeclared = !!msg.unoDeclared; // daca a apasat butonul UNO
    const hand = game.hands.get(client.id) || [];
    if (index < 0 || index >= hand.length) {
      sendJson(client.ws, { type: 'error', message: 'Index invalid.' });
      return;
    }
    const card = hand[index];
    const top = game.discard[game.discard.length - 1];
    if (!canPlay(card, top, game.currentColor)) {
      sendJson(client.ws, { type: 'error', message: 'Nu poti juca aceasta carte.' });
      return;
    }

    const cardsAfter = hand.length - 1;

    // joaca efectiv cartea
    hand.splice(index, 1);
    game.discard.push(card);

    // Gestionare efecte speciale pentru +2 si +4
    if (card.value === '+2') {
      // Adauga 2 la pendingDraw
      game.pendingDraw += 2;
      game.currentColor = card.color;
      broadcastText(`${client.name} a jucat +2! Urmatorul jucator va trage ${game.pendingDraw} carti.`);
    } else if (card.value === '+4') {
      // Adauga 4 la pendingDraw
      game.pendingDraw += 4;
      const chosen = msg.chosenColor;
      if (COLORS.includes(chosen)) {
        game.currentColor = chosen;
      } else {
        game.currentColor = COLORS[Math.floor(Math.random() * COLORS.length)];
      }
      broadcastText(`${client.name} a jucat +4! Urmatorul jucator va trage ${game.pendingDraw} carti.`);
    } else if (card.value === 'REVERSE') {
      // Inverseaza directia jocului (schimba de la inainte la inapoi sau invers)
      game.direction = -game.direction;
      game.currentColor = card.color;
      game.pendingDraw = 0;
      broadcastText(`${client.name} a jucat REVERSE! Directia jocului s-a inversat.`);
    } else if (card.value === 'SKIP') {
      // Sare peste urmatorul jucator - il blocheaza
      game.currentColor = card.color;
      game.pendingDraw = 0;
      broadcastText(`${client.name} a jucat SKIP! Urmatorul jucator este blocat si sarit.`);
      // Sare peste urmatorul jucator (trece direct la urmatorul dupa el)
      game.currentPlayerId = getNextPlayerId(); // Primul next = jucatorul sarit
      game.currentPlayerId = getNextPlayerId(); // Al doilea next = jucatorul care poate juca
    } else if (card.color === 'wild') {
      const chosen = msg.chosenColor;
      if (COLORS.includes(chosen)) {
        game.currentColor = chosen;
      } else {
        game.currentColor = COLORS[Math.floor(Math.random() * COLORS.length)];
      }
      game.pendingDraw = 0; // Reset pending draw pentru WILD normal
    } else {
      game.currentColor = card.color;
      game.pendingDraw = 0; // Reset pending draw pentru carti normale
    }

    broadcastText(`${client.name} a jucat o carte.`);

    // REGULA UNO: daca ramai cu 1 carte si NU ai declarat UNO -> penalizare 2 carti
    if (cardsAfter === 1) {
      if (unoDeclared) {
        broadcastText(`${client.name} a declarat UNO!`);
      } else {
        broadcastText(`${client.name} NU a declarat UNO – penalizare 2 carti.`);
        reshuffleIfNeeded();
        for (let i = 0; i < 2 && game.deck.length > 0; i++) {
          hand.push(game.deck.pop());
        }
      }
    }

    // a castigat?
    if (hand.length === 0) {
      broadcastText(`${client.name} a castigat partida!`);
      game.started = false;
      game.pendingDraw = 0;
      broadcastState();
      return;
    }

    // Treci la urmatorul jucator (daca nu a fost deja setat de REVERSE sau SKIP)
    if (card.value !== 'REVERSE' && card.value !== 'SKIP') {
      game.currentPlayerId = getNextPlayerId();
    } else if (card.value === 'REVERSE') {
      // Dupa REVERSE, trece la urmatorul jucator in noua directie
      game.currentPlayerId = getNextPlayerId();
    }
    
    // Daca exista pendingDraw (de la +2 sau +4), trage automat cartile pentru urmatorul jucator
    if (game.pendingDraw > 0) {
      const nextPlayerId = game.currentPlayerId;
      const nextPlayerHand = game.hands.get(nextPlayerId) || [];
      
      reshuffleIfNeeded();
      const cardsToDraw = game.pendingDraw;
      for (let i = 0; i < cardsToDraw && game.deck.length > 0; i++) {
        const c = game.deck.pop();
        nextPlayerHand.push(c);
      }
      game.hands.set(nextPlayerId, nextPlayerHand);
      
      const nextPlayer = clients.find(c => c.id === nextPlayerId);
      const nextPlayerName = nextPlayer ? (nextPlayer.username || nextPlayer.name) : 'Jucator';
      broadcastText(`${nextPlayerName} a tras automat ${cardsToDraw} carti (de la +2/+4).`);
      
      game.pendingDraw = 0; // Reset pending draw
      
      // Treci la urmatorul jucator (care a tras cartile)
      game.currentPlayerId = getNextPlayerId();
    }
    
    broadcastState();
    return;
  }

  // ---------------- DRAW (Trage carte) ----------------
  if (msg.type === 'draw') {
    // Nu permite trasul manual daca exista pendingDraw (cartile se trag automat)
    if (game.pendingDraw > 0) {
      sendJson(client.ws, { type: 'error', message: 'Trebuie sa accepti cartile de la +2/+4. Ele se trag automat.' });
      return;
    }
    
    reshuffleIfNeeded();
    if (game.deck.length === 0) {
      broadcastText('Nu mai sunt carti in pachet. Remiza.');
      game.started = false;
      game.pendingDraw = 0;
      broadcastState();
      return;
    }
    const hand = game.hands.get(client.id) || [];
    
    // Trage o singura carte normala
    const c = game.deck.pop();
    hand.push(c);
    game.hands.set(client.id, hand);
    broadcastText(`${client.name} a tras o carte.`);
    
    // Treci la urmatorul jucator
    game.currentPlayerId = getNextPlayerId();
    
    broadcastState();
    return;
  }
}

// ----------------- PORNIRE SERVER -----------------

server.listen(PORT, () => {
  console.log('Server HTTP + WebSocket UNO pornit pe http://localhost:' + PORT);
  console.log('Baza de date SQLite initializata: uno_database.db');
  console.log('Utilizatorii sunt stocati persistent in baza de date.');
});

let ws = null;
let state = null;
let youId = null;
let unoArmed = false; // daca a apasat declarare UNO

// Helper function to get card image
function getCardImage(card, size = 'normal') {
    if (!card) {
        return createBackCardDataURL(size);
    }
    
    const color = card.color || '';
    const value = card.value || '';
    
    if (color === 'wild') {
        return createWildCardDataURL(size, value);
    }
    
    return createColoredCardDataURL(color, value, size);
}

function createBackCardDataURL(size) {
    const width = size === 'small' ? 60 : 100;
    const height = size === 'small' ? 90 : 140;
    
    const svg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="backGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style="stop-color:#fbbf24;stop-opacity:1" />
                    <stop offset="100%" style="stop-color:#ef4444;stop-opacity:1" />
                </linearGradient>
            </defs>
            <rect width="${width}" height="${height}" rx="8" fill="url(#backGrad)" stroke="#facc15" stroke-width="2"/>
            <text x="50%" y="50%" font-family="Arial Black, sans-serif" font-size="${width * 0.3}" 
                  fill="white" text-anchor="middle" dominant-baseline="middle" font-weight="bold">UNO</text>
        </svg>
    `;
    return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svg)));
}

function createWildCardDataURL(size, value = 'WILD') {
    const width = size === 'small' ? 60 : 100;
    const height = size === 'small' ? 90 : 140;
    
    const isPlus4 = value === '+4';
    const textToShow = isPlus4 ? '+4' : 'WILD';
    const fontSize = isPlus4 ? width * 0.3 : width * 0.25;
    
    const svg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="wildGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style="stop-color:#ef4444;stop-opacity:1" />
                    <stop offset="33%" style="stop-color:#eab308;stop-opacity:1" />
                    <stop offset="66%" style="stop-color:#22c55e;stop-opacity:1" />
                    <stop offset="100%" style="stop-color:#3b82f6;stop-opacity:1" />
                </linearGradient>
            </defs>
            <rect width="${width}" height="${height}" rx="8" fill="url(#wildGrad)" stroke="#fff" stroke-width="2"/>
            <text x="50%" y="50%" font-family="Arial Black, sans-serif" font-size="${fontSize}" 
                  fill="white" text-anchor="middle" dominant-baseline="middle" font-weight="bold">${textToShow}</text>
            ${isPlus4 ? `
            <text x="${width * 0.15}" y="${height * 0.25}" font-family="Arial Black, sans-serif" font-size="${width * 0.2}" 
                  fill="white" font-weight="bold">+4</text>
            <text x="${width * 0.85}" y="${height * 0.85}" font-family="Arial Black, sans-serif" font-size="${width * 0.2}" 
                  fill="white" text-anchor="end" font-weight="bold">+4</text>
            ` : ''}
        </svg>
    `;
    return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svg)));
}

function createColoredCardDataURL(color, value, size) {
    const width = size === 'small' ? 60 : 100;
    const height = size === 'small' ? 90 : 140;
    
    const colorMap = {
        'red': '#ef4444',
        'yellow': '#eab308',
        'green': '#22c55e',
        'blue': '#3b82f6'
    };
    
    const bgColor = colorMap[color] || '#64748b';
    const textColor = color === 'yellow' ? '#111827' : 'white';
    
    // Pentru cartile speciale, folosim un font mai mic si stil special
    const isSpecial = value === '+2' || value === '+4' || value === 'REVERSE' || value === 'SKIP';
    const mainFontSize = isSpecial ? width * 0.25 : width * 0.4;
    const cornerFontSize = isSpecial ? width * 0.15 : width * 0.25;
    
    // Iconuri pentru REVERSE si SKIP
    let centerContent = `<text x="50%" y="50%" font-family="Arial Black, sans-serif" font-size="${mainFontSize}" 
                  fill="${textColor}" text-anchor="middle" dominant-baseline="middle" font-weight="bold">${value}</text>`;
    
    if (value === 'REVERSE') {
      // Icon sageata inversata
      const arrowSize = width * 0.3;
      centerContent = `
        <path d="M ${width*0.5 - arrowSize*0.3} ${height*0.5 - arrowSize*0.2} L ${width*0.5 + arrowSize*0.3} ${height*0.5} L ${width*0.5 - arrowSize*0.3} ${height*0.5 + arrowSize*0.2} Z" 
              fill="${textColor}" stroke="${textColor}" stroke-width="2"/>
        <path d="M ${width*0.5 + arrowSize*0.3} ${height*0.5 - arrowSize*0.2} L ${width*0.5 - arrowSize*0.3} ${height*0.5} L ${width*0.5 + arrowSize*0.3} ${height*0.5 + arrowSize*0.2} Z" 
              fill="${textColor}" stroke="${textColor}" stroke-width="2"/>
        <text x="50%" y="${height*0.5 + arrowSize*0.6}" font-family="Arial Black, sans-serif" font-size="${width * 0.15}" 
              fill="${textColor}" text-anchor="middle" font-weight="bold">REV</text>
      `;
    } else if (value === 'SKIP') {
      // Icon stop/circle
      const circleSize = width * 0.25;
      centerContent = `
        <circle cx="50%" cy="${height*0.45}" r="${circleSize}" fill="none" stroke="${textColor}" stroke-width="3"/>
        <path d="M ${width*0.5 - circleSize*0.4} ${height*0.45} L ${width*0.5 + circleSize*0.4} ${height*0.45}" 
              stroke="${textColor}" stroke-width="3" stroke-linecap="round"/>
        <text x="50%" y="${height*0.5 + circleSize*0.8}" font-family="Arial Black, sans-serif" font-size="${width * 0.18}" 
              fill="${textColor}" text-anchor="middle" font-weight="bold">SKIP</text>
      `;
    }
    
    const svg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <rect width="${width}" height="${height}" rx="8" fill="${bgColor}" stroke="#fff" stroke-width="2"/>
            <circle cx="${width * 0.2}" cy="${height * 0.2}" r="${width * 0.15}" fill="white" opacity="0.3"/>
            <circle cx="${width * 0.8}" cy="${height * 0.8}" r="${width * 0.15}" fill="white" opacity="0.3"/>
            ${centerContent}
            ${value !== 'REVERSE' && value !== 'SKIP' ? `
            <text x="${width * 0.15}" y="${height * 0.25}" font-family="Arial Black, sans-serif" font-size="${cornerFontSize}" 
                  fill="${textColor}" font-weight="bold">${value}</text>
            <text x="${width * 0.85}" y="${height * 0.85}" font-family="Arial Black, sans-serif" font-size="${cornerFontSize}" 
                  fill="${textColor}" text-anchor="end" font-weight="bold">${value}</text>
            ` : `
            <text x="${width * 0.15}" y="${height * 0.25}" font-family="Arial Black, sans-serif" font-size="${width * 0.12}" 
                  fill="${textColor}" font-weight="bold">${value.substring(0, 3)}</text>
            <text x="${width * 0.85}" y="${height * 0.85}" font-family="Arial Black, sans-serif" font-size="${width * 0.12}" 
                  fill="${textColor}" text-anchor="end" font-weight="bold">${value.substring(0, 3)}</text>
            `}
        </svg>
    `;
    return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svg)));
}

const statusEl = document.getElementById('status');
const playerInfoEl = document.getElementById('playerInfo');
const playersListEl = document.getElementById('playersList');
const playerHandEl = document.getElementById('playerHand');
const discardEl = document.getElementById('discardPile');
const currentColorEl = document.getElementById('currentColor');
const drawBtn = document.getElementById('drawBtn');
const startBtn = document.getElementById('startBtn');
const registerBtn = document.getElementById('registerBtn');
const loginBtn = document.getElementById('loginBtn');
const unoBtn = document.getElementById('unoBtn');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');

function connect() {
  ws = new WebSocket(`ws://${window.location.hostname}:3000`);

  ws.onopen = () => {
    setStatus('Conectat la server. Te rog să te înregistrezi sau să te loghezi.');
  };

  ws.onmessage = (event) => {
    let msg;
    try {
      msg = JSON.parse(event.data);
    } catch {
      return;
    }
    handleMessage(msg);
  };

  ws.onclose = () => {
    setStatus('Conexiune inchisa. Reincarca pagina pentru a reconecta.');
    drawBtn.disabled = true;
    startBtn.disabled = true;
    registerBtn.disabled = true;
    loginBtn.disabled = true;
    unoBtn.disabled = true;
  };
}

function handleMessage(msg) {
  if (msg.type === 'welcome') {
    youId = msg.id;
    playerInfoEl.textContent = `Tu: client #${msg.id} (neautentificat)`;
    return;
  }

  if (msg.type === 'info') {
    setStatus(msg.message);
    return;
  }

  if (msg.type === 'error') {
    setStatus('Eroare: ' + msg.message);
    return;
  }

  if (msg.type === 'state') {
    state = msg;
    renderState();
    return;
  }
}

function setStatus(text) {
  statusEl.textContent = text;
}

function renderState() {
  if (!state) return;

  // info utilizator
  if (state.loggedIn) {
    playerInfoEl.textContent =
      `Tu: ${state.username} (ID ${state.youId})${state.started ? '' : ' – astepti inceperea jocului'}`;
  }

  // jucatori
  playersListEl.innerHTML = '';
  state.players.forEach(p => {
    const li = document.createElement('li');
    const isCurrent = p.id === state.currentPlayerId && state.started;
    const isYou = p.id === state.youId;
    li.textContent = p.name + ` – ${p.handCount} carti`;
    if (isYou) li.textContent += ' (TU)';
    if (isCurrent) {
      const span = document.createElement('span');
      span.textContent = ' – randul lui';
      li.appendChild(span);
    }
    playersListEl.appendChild(li);
  });

  // mana ta
  playerHandEl.innerHTML = '';
  (state.hand || []).forEach((card, index) => {
    const div = document.createElement('div');
    div.className = 'card small card-image';
    const img = document.createElement('img');
    img.src = getCardImage(card, 'small');
    img.alt = `${card.color} ${card.value}`;
    img.style.width = '100%';
    img.style.height = '100%';
    img.style.objectFit = 'cover';
    img.style.borderRadius = '8px';
    div.appendChild(img);
    div.addEventListener('click', () => {
      onPlayCard(index, card);
    });
    playerHandEl.appendChild(div);
  });

  // cartea de pe masa
  if (state.topCard) {
    discardEl.className = 'card card-image';
    discardEl.innerHTML = '';
    const img = document.createElement('img');
    img.src = getCardImage(state.topCard, 'normal');
    img.alt = `${state.topCard.color} ${state.topCard.value}`;
    img.style.width = '100%';
    img.style.height = '100%';
    img.style.objectFit = 'cover';
    img.style.borderRadius = '8px';
    discardEl.appendChild(img);
  } else {
    discardEl.className = 'card placeholder';
    discardEl.innerHTML = '<span>?</span>';
  }

  // pachetul de carti (spatele cartilor)
  const drawPileEl = document.getElementById('drawPile');
  if (drawPileEl && !drawPileEl.querySelector('img')) {
    drawPileEl.innerHTML = '';
    const img = document.createElement('img');
    img.src = getCardImage(null, 'normal');
    img.alt = 'Pachet';
    img.style.width = '100%';
    img.style.height = '100%';
    img.style.objectFit = 'cover';
    img.style.borderRadius = '8px';
    drawPileEl.appendChild(img);
  }

  // Afiseaza culoarea curenta, directia si pending draw daca exista
  let colorText = 'Culoare curenta: ' + (state.currentColor ? state.currentColor.toUpperCase() : '-');
  if (state.direction !== undefined) {
    const directionText = state.direction > 0 ? '▶ Inainte' : '◀ Inapoi';
    colorText += ` | ${directionText}`;
  }
  if (state.pendingDraw && state.pendingDraw > 0) {
    colorText += ` | Urmatorul jucator trage ${state.pendingDraw} carti`;
  }
  currentColorEl.textContent = colorText;

  // butoane
  const myTurn = state.started && state.currentPlayerId === state.youId;
  drawBtn.disabled = !myTurn;
  unoBtn.disabled = !myTurn; // poti declara UNO doar la randul tau
  startBtn.disabled = !!state.started;
}

function mapColorClass(color) {
  if (!color) return 'placeholder';
  if (color === 'wild') return 'wild';
  return color;
}

async function onPlayCard(index, card) {
  if (!state || !state.started) {
    setStatus('Jocul nu a inceput inca.');
    return;
  }
  if (state.currentPlayerId !== state.youId) {
    setStatus('Nu este randul tau.');
    return;
  }

  let chosenColor = null;
  if (card.color === 'wild') {
    const isPlus4 = card.value === '+4';
    chosenColor = await showColorPicker(isPlus4);
    if (!chosenColor) {
      setStatus(`Trebuie sa alegi o culoare pentru cartea ${isPlus4 ? '+4' : 'WILD'}.`);
      return;
    }
  }

  const msg = {
    type: 'play',
    index,
    unoDeclared: unoArmed
  };
  if (chosenColor) msg.chosenColor = chosenColor;

  // dupa ce ai jucat, UNO revine la false
  unoArmed = false;
  ws.send(JSON.stringify(msg));
}

function showColorPicker(isPlus4 = false) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 1000; display: flex; justify-content: center; align-items: center;';
    
    const picker = document.createElement('div');
    picker.style.cssText = 'background: #1e293b; padding: 30px; border-radius: 12px; border: 2px solid #334155; box-shadow: 0 8px 32px rgba(0,0,0,0.5);';
    
    const title = document.createElement('h3');
    title.textContent = isPlus4 ? 'Alege culoarea pentru cartea +4' : 'Alege culoarea pentru cartea WILD';
    title.style.cssText = 'color: white; margin-bottom: 20px; text-align: center;';
    picker.appendChild(title);
    
    const colors = [
      { name: 'red', label: 'Roșu', color: '#ef4444' },
      { name: 'yellow', label: 'Galben', color: '#eab308' },
      { name: 'green', label: 'Verde', color: '#22c55e' },
      { name: 'blue', label: 'Albastru', color: '#3b82f6' }
    ];
    
    const colorGrid = document.createElement('div');
    colorGrid.style.cssText = 'display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;';
    
    colors.forEach(c => {
      const btn = document.createElement('button');
      btn.textContent = c.label;
      btn.style.cssText = `padding: 20px 30px; border-radius: 8px; border: 2px solid ${c.color}; background: ${c.color}; color: ${c.name === 'yellow' ? '#111827' : 'white'}; font-weight: bold; cursor: pointer; transition: all 0.2s; font-size: 1rem;`;
      btn.onmouseover = () => {
        btn.style.transform = 'scale(1.05)';
        btn.style.boxShadow = `0 4px 16px ${c.color}80`;
      };
      btn.onmouseout = () => {
        btn.style.transform = 'scale(1)';
        btn.style.boxShadow = 'none';
      };
      btn.onclick = () => {
        overlay.remove();
        resolve(c.name);
      };
      colorGrid.appendChild(btn);
    });
    
    picker.appendChild(colorGrid);
    overlay.appendChild(picker);
    overlay.onclick = (e) => {
      if (e.target === overlay) {
        overlay.remove();
        resolve(null);
      }
    };
    
    document.body.appendChild(overlay);
  });
}

// ----------------- Evenimente butoane -----------------

drawBtn.addEventListener('click', () => {
  if (!state || !state.started) return;
  if (state.currentPlayerId !== state.youId) return;
  ws.send(JSON.stringify({ type: 'draw' }));
});

startBtn.addEventListener('click', () => {
  ws.send(JSON.stringify({ type: 'start' }));
});

registerBtn.addEventListener('click', () => {
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();
  ws.send(JSON.stringify({ type: 'register', username, password }));
});

loginBtn.addEventListener('click', () => {
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();
  ws.send(JSON.stringify({ type: 'login', username, password }));
});

unoBtn.addEventListener('click', () => {
  if (!state || !state.started) return;
  if (state.currentPlayerId !== state.youId) return;
  if ((state.hand || []).length <= 1) {
    setStatus('Nu poti declara UNO fara sa joci o carte care te lasa cu 1 carte.');
    return;
  }
  unoArmed = true;
  setStatus('Ai declarat UNO pentru urmatoarea mutare (daca ramai cu 1 carte).');
});

connect();

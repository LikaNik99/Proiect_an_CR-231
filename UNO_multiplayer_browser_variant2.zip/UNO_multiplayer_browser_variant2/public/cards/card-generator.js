// Card image generator - creates SVG-based UNO card images
function getCardImagePath(card) {
    if (!card) return 'cards/back.svg';
    
    const color = card.color || '';
    const value = card.value || '';
    
    if (color === 'wild') {
        return `cards/wild.svg`;
    }
    
    return `cards/${color}_${value}.svg`;
}

function createCardSVG(card, size = 'normal') {
    const width = size === 'small' ? 60 : 100;
    const height = size === 'small' ? 90 : 140;
    
    if (!card || card.color === 'back') {
        return createBackCardSVG(width, height);
    }
    
    const color = card.color || '';
    const value = card.value || '';
    
    if (color === 'wild') {
        return createWildCardSVG(width, height);
    }
    
    return createColoredCardSVG(color, value, width, height);
}

function createBackCardSVG(width, height) {
    return `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="backGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style="stop-color:#fbbf24;stop-opacity:1" />
                    <stop offset="100%" style="stop-color:#ef4444;stop-opacity:1" />
                </linearGradient>
            </defs>
            <rect width="${width}" height="${height}" rx="8" fill="url(#backGrad)" stroke="#facc15" stroke-width="2"/>
            <text x="50%" y="50%" font-family="Arial Black, sans-serif" font-size="${width * 0.3}" 
                  fill="white" text-anchor="middle" dominant-baseline="middle" font-weight="bold">UNO</text>
        </svg>
    `;
}

function createWildCardSVG(width, height) {
    const colors = ['#ef4444', '#eab308', '#22c55e', '#3b82f6'];
    const colorStops = colors.map((c, i) => 
        `<stop offset="${i * 33.33}%" style="stop-color:${c};stop-opacity:1" />`
    ).join('');
    
    return `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="wildGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    ${colorStops}
                    <stop offset="100%" style="stop-color:${colors[0]};stop-opacity:1" />
                </linearGradient>
            </defs>
            <rect width="${width}" height="${height}" rx="8" fill="url(#wildGrad)" stroke="#fff" stroke-width="2"/>
            <text x="50%" y="50%" font-family="Arial Black, sans-serif" font-size="${width * 0.25}" 
                  fill="white" text-anchor="middle" dominant-baseline="middle" font-weight="bold">WILD</text>
        </svg>
    `;
}

function createColoredCardSVG(color, value, width, height) {
    const colorMap = {
        'red': '#ef4444',
        'yellow': '#eab308',
        'green': '#22c55e',
        'blue': '#3b82f6'
    };
    
    const bgColor = colorMap[color] || '#64748b';
    const textColor = color === 'yellow' ? '#111827' : 'white';
    
    return `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <rect width="${width}" height="${height}" rx="8" fill="${bgColor}" stroke="#fff" stroke-width="2"/>
            <circle cx="${width * 0.2}" cy="${height * 0.2}" r="${width * 0.15}" fill="white" opacity="0.3"/>
            <circle cx="${width * 0.8}" cy="${height * 0.8}" r="${width * 0.15}" fill="white" opacity="0.3"/>
            <text x="50%" y="50%" font-family="Arial Black, sans-serif" font-size="${width * 0.4}" 
                  fill="${textColor}" text-anchor="middle" dominant-baseline="middle" font-weight="bold">${value}</text>
            <text x="${width * 0.15}" y="${height * 0.25}" font-family="Arial Black, sans-serif" font-size="${width * 0.25}" 
                  fill="${textColor}" font-weight="bold">${value}</text>
            <text x="${width * 0.85}" y="${height * 0.85}" font-family="Arial Black, sans-serif" font-size="${width * 0.25}" 
                  fill="${textColor}" text-anchor="end" font-weight="bold">${value}</text>
        </svg>
    `;
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { getCardImagePath, createCardSVG };
}

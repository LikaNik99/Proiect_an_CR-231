// Card image system - generates data URLs for UNO cards
function getCardImage(card, size = 'normal') {
    if (!card) {
        return createBackCardDataURL(size);
    }
    
    const color = card.color || '';
    const value = card.value || '';
    
    if (color === 'wild') {
        return createWildCardDataURL(size);
    }
    
    return createColoredCardDataURL(color, value, size);
}

function createBackCardDataURL(size) {
    const width = size === 'small' ? 60 : 100;
    const height = size === 'small' ? 90 : 140;
    
    const svg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="backGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style="stop-color:#fbbf24;stop-opacity:1" />
                    <stop offset="100%" style="stop-color:#ef4444;stop-opacity:1" />
                </linearGradient>
            </defs>
            <rect width="${width}" height="${height}" rx="8" fill="url(#backGrad)" stroke="#facc15" stroke-width="2"/>
            <text x="50%" y="50%" font-family="Arial Black, sans-serif" font-size="${width * 0.3}" 
                  fill="white" text-anchor="middle" dominant-baseline="middle" font-weight="bold">UNO</text>
        </svg>
    `;
    return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svg)));
}

function createWildCardDataURL(size) {
    const width = size === 'small' ? 60 : 100;
    const height = size === 'small' ? 90 : 140;
    
    const svg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="wildGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style="stop-color:#ef4444;stop-opacity:1" />
                    <stop offset="33%" style="stop-color:#eab308;stop-opacity:1" />
                    <stop offset="66%" style="stop-color:#22c55e;stop-opacity:1" />
                    <stop offset="100%" style="stop-color:#3b82f6;stop-opacity:1" />
                </linearGradient>
            </defs>
            <rect width="${width}" height="${height}" rx="8" fill="url(#wildGrad)" stroke="#fff" stroke-width="2"/>
            <text x="50%" y="50%" font-family="Arial Black, sans-serif" font-size="${width * 0.25}" 
                  fill="white" text-anchor="middle" dominant-baseline="middle" font-weight="bold">WILD</text>
        </svg>
    `;
    return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svg)));
}

function createColoredCardDataURL(color, value, size) {
    const width = size === 'small' ? 60 : 100;
    const height = size === 'small' ? 90 : 140;
    
    const colorMap = {
        'red': '#ef4444',
        'yellow': '#eab308',
        'green': '#22c55e',
        'blue': '#3b82f6'
    };
    
    const bgColor = colorMap[color] || '#64748b';
    const textColor = color === 'yellow' ? '#111827' : 'white';
    
    const svg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <rect width="${width}" height="${height}" rx="8" fill="${bgColor}" stroke="#fff" stroke-width="2"/>
            <circle cx="${width * 0.2}" cy="${height * 0.2}" r="${width * 0.15}" fill="white" opacity="0.3"/>
            <circle cx="${width * 0.8}" cy="${height * 0.8}" r="${width * 0.15}" fill="white" opacity="0.3"/>
            <text x="50%" y="50%" font-family="Arial Black, sans-serif" font-size="${width * 0.4}" 
                  fill="${textColor}" text-anchor="middle" dominant-baseline="middle" font-weight="bold">${value}</text>
            <text x="${width * 0.15}" y="${height * 0.25}" font-family="Arial Black, sans-serif" font-size="${width * 0.25}" 
                  fill="${textColor}" font-weight="bold">${value}</text>
            <text x="${width * 0.85}" y="${height * 0.85}" font-family="Arial Black, sans-serif" font-size="${width * 0.25}" 
                  fill="${textColor}" text-anchor="end" font-weight="bold">${value}</text>
        </svg>
    `;
    return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svg)));
}
